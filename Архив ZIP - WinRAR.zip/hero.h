#include <string>
#include <vector>
using namespace std;

class Hero{
private:
        HDC hero_pic;
        HDC  map_picture;
        int x = 280;
        int y = 55;
        int x_pic = 0;
        int y_pic = 0;
        int x_speed = 25;
        int y_speed = 25;
        int physic_speed = 4;
        int i_pos = 0;
        int j_pos = 0;
        int pref_i_pos = 0;
        int pref_j_pos = 0;
       // int next_i_pos = 0;
       // int next_j_pos = 0;
       // int pref_next_i_pos = 0;
       // int pref_next_j_pos = 0;

        int height1 = 74;
        int width1= 40;

        int height = 183;
        int width = 99;

        int health = 2;
        char* health_char = new char[2];
        int armor = 0;
        char* armor_char = new char[2];
        int tool = 0;
        char* tool_char = new char[2];
        int key = 0;
        char* key_char = new char[2];

        bool move_right_flag = true;
        bool move_left_flag = true;
        bool move_up_flag = true;
        bool move_down_flag = true;
        bool physic_flag = false;
        bool event;
        bool light= false;
        string last_rotation = "down";
        vector<int> up_left_corn;
        vector<int> down_left_corn;
        vector<int> up_right_corn;
        vector<int> down_right_corn;
public:
    Hero(HDC hero_pic,HDC map_picture){
        up_left_corn.push_back(x);
        up_left_corn.push_back(y);
        down_left_corn.push_back(x);
        down_left_corn.push_back(y + height);
        up_right_corn.push_back(x + width);
        up_right_corn.push_back(y);
        down_right_corn.push_back(x + width);
        down_right_corn.push_back(y + height);
        this->hero_pic = hero_pic;
        this->map_picture = map_picture;

        health_char[0] = char(health + '0');
        health_char[1] = '\0';
        armor_char[0] = char(armor + '0');
        armor_char[1] = '\0';
        tool_char[0] = char(tool + '0');
        tool_char[1] = '\0';
        key_char[0] = char(key + '0');
        key_char[1] = '\0';
    }

    bool dead() {
        if (health == 0) {
            return true;
        }
        return false;
    }

    void draw_hero() {
        Win32::TransparentBlt(txDC(), x, y, width1, height1,
            hero_pic, x_pic, y_pic, width, height, RGB(255, 0, 255));
    }

   /* void check_physic(){
        if(txGetPixel(down_left_corn[0]+width/2,down_left_corn[1]) == RGB(255,216,0)){
            physic_flag = true;
        }
        else{
            physic_flag = false;
        }
    }
    void check_move_sides(){
        if(txGetPixel(up_right_corn[0] + x_speed, up_right_corn[1]) == RGB(255,0,0) ||
                       up_right_corn[0] >= 1200 ||
                       txGetPixel(down_right_corn[0] + x_speed, down_right_corn[1]) == RGB(255,0,0)){
            move_right_flag = false;
        }
        else{
            move_right_flag = true;
        }

        if(txGetPixel(up_right_corn[0], up_right_corn[1] - y_speed) == RGB(255,0,0) ||
                       up_left_corn[1] <= 0 ||
                       txGetPixel(up_left_corn[0],up_left_corn[1] - y_speed) == RGB(255,0,0)){
            move_up_flag = false;
        }
        else{
            move_up_flag = true;
        }

        if(txGetPixel(up_left_corn[0] - x_speed, up_right_corn[1]) == RGB(255,0,0) ||
                       up_left_corn[0] <= 0 ||
                       txGetPixel(down_left_corn[0] - x_speed, down_left_corn[1]) == RGB(255,0,0)){
            move_left_flag = false;
        }
        else{
            move_left_flag = true;
        }

        if(txGetPixel (down_left_corn[0], down_left_corn[1] + y_speed) == RGB(255,0,0) ||
                       down_left_corn[1] >= 900 ||
                       txGetPixel (down_right_corn[0], down_right_corn[1] + y_speed) == RGB(255,0,0)){
            move_down_flag = false;
        }
        else{
            move_down_flag = true;
        }
    }

    void check_events(){
        if(physic_flag && txGetPixel(down_left_corn[0],down_left_corn[1]+physic_speed)!= RGB(255,0,0) &&
            txGetPixel(down_left_corn[0] + width/2,down_left_corn[1]+physic_speed)!= RGB(255,0,0) &&
            txGetPixel(down_right_corn[0],down_right_corn[1]+physic_speed)!= RGB(255,0,0)){
            y=y+physic_speed;
        }
        if(GetAsyncKeyState(VK_RIGHT)){
            _move_right();
        }

        else if(GetAsyncKeyState(VK_LEFT)){
            _move_left();
        }

        else if(GetAsyncKeyState(VK_UP)){
            _move_up();
        }
        else if(GetAsyncKeyState(VK_DOWN)){
            _move_down();
        }
        else{
            _stay();
        }
        up_left_corn[0] = x;
        up_left_corn[1] = y;
        down_left_corn[0] = x;
        down_left_corn[1] = y + height;
        up_right_corn[0] = x + width;
        up_right_corn[1] = y;
        down_right_corn[0] = x + width;
        down_right_corn[1] = y + height;
    }

    void _move_right(){
        if(last_rotation!="right"){
            x_pic = 0;
        }
        width = 104;
        height = 183;
        y_pic = 2*height;
        x_pic+=width;
        if(move_right_flag){
            x=x+x_speed;
        }
        if(x_pic > 3*width){
            x_pic = 0;
        }
        last_rotation = "right";
    }

    void _move_left(){
        if(last_rotation != "left"){
            x_pic = 0;
        }
        width = 105;
        height = 183;
        y_pic = 1*height;
        x_pic+=width;
        if(move_left_flag){
            x = x - x_speed;
        }
        if(x_pic > 3*width){
            x_pic = 0;
        }
        last_rotation = "left";
    }

    void _move_up(){
        if(last_rotation!="up"){
            x_pic = 0;
        }
        width = 99;
        height = 183;
        y_pic = 3*height;
        x_pic+=width;
        if(move_up_flag){
            y = y - y_speed;
        }
        if(x_pic > 3*width){
            x_pic = 0;
        }
        last_rotation = "up";
    }

    void _move_down(){
        if(last_rotation!="down"){
            x_pic = 0;
        }
        width = 99;
        height = 183;
        y_pic = 0*height;
        x_pic+=width;
        if(move_down_flag){
            y = y + y_speed;
        }
        if(x_pic > 3*width){
            x_pic = 0;
        }
        last_rotation = "down";
    }*/
    bool check_events() {
        /*pref_i_pos = i_pos;
        pref_j_pos = j_pos;
        _check_next_pos();
        pref_next_i_pos = next_i_pos;
        pref_next_j_pos = next_j_pos;*/
        if (GetAsyncKeyState(VK_RIGHT) && move_right_flag) {
            _move_right();
            event = true;
        }

        else if (GetAsyncKeyState(VK_LEFT) && move_left_flag) {
            _move_left();
            event = true;

        }

        else if (GetAsyncKeyState(VK_UP) && move_up_flag) {
            _move_up();
            event = true;

        }
        else if (GetAsyncKeyState(VK_DOWN) && move_down_flag) {
            _move_down();
            event = true;

        }
        else {
            event = false;
        }
       /* else {
            _stay();
            if (last_rotation != "down") {
                event = true;
            }
            else {
                event = false;
            }
        }*/
        health_char[0] = char(health + '0');
        health_char[1] = '\0';
        armor_char[0] = char(armor + '0');
        armor_char[1] = '\0';
        tool_char[0] = char(tool + '0');
        tool_char[1] = '\0';
        key_char[0] = char(key + '0');
        key_char[1] = '\0';
        return event;

    }
    void check_move_sides() {
        if (x + 100 >= 750 || txGetPixel(x + 80, y) == RGB(0, 255, 255)) {
            move_right_flag = false;
        }
        else {
            move_right_flag = true;
        }

        if (x - 100 <= 250 || txGetPixel(x - 25, y) == RGB(0, 255, 255)) {
            move_left_flag = false;
        }
        else {
            move_left_flag = true;
        }

        if (y + 100 >= 550 || txGetPixel(x, y+90) == RGB(0, 255, 255)) {
            move_down_flag = false;
        }
        else {
            move_down_flag = true;
        }

        if (y - 100 <= 50 || txGetPixel(x, y-15) == RGB(0, 255, 255)) {
            move_up_flag = false;
        }
        else {
            move_up_flag = true;
        }
        pref_i_pos = i_pos;
        pref_j_pos = j_pos;
        //_check_next_pos();
    }
    void _move_up() {
        if (last_rotation != "up") {
            x_pic = 0;
        }
        width = 99;
        height = 183;
        i_pos = i_pos - 1;
        y_pic = 3 * height;
        int y1 = y;
        while (y > y1 - 100) {
            txSleep(100);
            Win32::TransparentBlt(txDC(), 250 + j_pos * 100, 50 + (i_pos+1) * 100, 100, 100, map_picture, j_pos * 100, (i_pos+1) * 100, 100, 100, -1);
            Win32::TransparentBlt(txDC(), 250 + j_pos * 100, 50 + i_pos * 100, 100, 100, map_picture, j_pos * 100, i_pos * 100, 100, 100, -1);
            x_pic += width;
            y = y - y_speed;
            if (x_pic > 3 * width) {
                x_pic = 0;
            }
            draw_hero();
            last_rotation = "up";
        }
    }
    void _move_down() {
        if (last_rotation != "down") {
            x_pic = 0;
        }
        width = 99;
        height = 183;
        i_pos++;
        y_pic = 0 * height;
        int y1 = y;
        while (y < y1 + 100) {
            txSleep(100);
            Win32::TransparentBlt(txDC(), 250 + j_pos * 100, 50 + (i_pos-1) * 100, 100, 100, map_picture, j_pos * 100, (i_pos-1) * 100, 100, 100, -1);
            Win32::TransparentBlt(txDC(), 250 + j_pos * 100, 50 + i_pos * 100, 100, 100, map_picture, j_pos * 100, i_pos * 100, 100, 100, -1);
            x_pic += width;
            y = y + y_speed;
            if (x_pic > 3 * width) {
                x_pic = 0;
            }
            draw_hero();
            last_rotation = "down";
        }
    }
    void _move_left() {
        if (last_rotation != "left") {
            x_pic = 0;
        }
        width = 105;
        height = 183;
        j_pos = j_pos - 1;
        y_pic = 1 * height;
        int x1 = x;
        while (x > x1 - 100) {
            txSleep(100);
            Win32::TransparentBlt(txDC(), 250 + (j_pos+1) * 100, 50 + i_pos * 100, 100, 100, map_picture, (j_pos+1) * 100, i_pos * 100, 100, 100, -1);
            Win32::TransparentBlt(txDC(), 250 + j_pos * 100, 50 + i_pos * 100, 100, 100, map_picture, j_pos * 100, i_pos * 100, 100, 100, -1);
            x_pic += width;
            x = x - x_speed;
            if (x_pic > 3 * width) {
                x_pic = 0;
            }
            draw_hero();
            last_rotation = "left";
        }
    }
    void _move_right() {
        if (last_rotation != "right") {
            x_pic = 0;
        }
        width = 104;
        height = 183;
        j_pos++;
        y_pic = 2 * height;
        int x1 = x;
        while (x < x1 + 100) {
            txSleep(100);
            Win32::TransparentBlt(txDC(), 250 + (j_pos-1) * 100, 50 + i_pos * 100, 100, 100, map_picture, (j_pos-1) * 100, i_pos * 100, 100, 100, -1);
            Win32::TransparentBlt(txDC(), 250 + j_pos * 100, 50 + i_pos * 100, 100, 100, map_picture, j_pos * 100, i_pos * 100, 100, 100, -1);
            x_pic += width;
            x = x + x_speed;
            if (x_pic > 3 * width) {
                x_pic = 0;
            }
            draw_hero();
            last_rotation = "right";
        }
    }

    void _stay(){
        width = 99;
        height = 183;
        y_pic = 0;
        x_pic = 0;
        last_rotation = "down";
    }



    /*void _check_next_pos() {
        if (last_rotation == "right") {
            if (j_pos < 4 && move_right_flag) {
                next_j_pos = j_pos + 1;
                next_i_pos = i_pos;
            }
        }
        if (last_rotation == "left") {
            if (j_pos >0 && move_left_flag) {
                next_j_pos = j_pos - 1;
                next_i_pos = i_pos;
            }
        }
        if (last_rotation == "up") {
            if (i_pos > 0 && move_up_flag) {
                next_i_pos = i_pos - 1;
                next_j_pos = j_pos;
            }
        }
        if (last_rotation == "down" && move_down_flag) {
            if (i_pos < 4) {
                next_i_pos = i_pos + 1;
                next_j_pos = j_pos;
            }
        }
    }*/

    int get_x_pic(){
        return x_pic;
    }
    int get_y_pic(){
        return y_pic;
    }
    int get_width(){
        return width;
    }
    int get_height(){
        return height;
    }
    //////////////////////////////////////
    int get_health() {
        return health;
    }
    int get_armor() {
        return armor;
    }
    int get_tool() {
        return tool;
    }
    int get_key() {
        return key;
    }

    void set_health(int health) {
        this->health = health;
    }
    void set_armor(int armor) {
        this->armor = armor;
    }
    void set_tool(int tool) {
        this->tool = tool;
    }
    void set_key(int key) {
        this->key = key;
    }
    //////////////////////////////////////
    char* get_health_char() {
        return health_char;
    }
    char* get_armor_char() {
        return armor_char;
    }
    char* get_tool_char() {
        return tool_char;
    }
    char* get_key_char() {
        return key_char;
    }
    //////////////////////////////////////
    int get_i_pos() {
        return i_pos;
    }
    int get_j_pos() {
        return j_pos;
    }
    int get_pref_i_pos() {
        return pref_i_pos;
    }
    int get_pref_j_pos() {
        return pref_j_pos;
    }

    void set_i_pos(int i_pos) {
        this->i_pos = i_pos;
    }
    void set_j_pos(int j_pos) {
        this->j_pos = j_pos;
    }
    void set_pref_i_pos(int pref_i_pos) {
        this->pref_i_pos = pref_i_pos;
    }
    void set_pref_j_pos(int pref_j_pos) {
        this->pref_j_pos = pref_j_pos;
    }
    //////////////////////////////////////
    /*int get_next_i_pos() {
        return next_i_pos;
    }
    int get_next_j_pos() {
        return next_j_pos;
    }
    int get_pref_next_i_pos() {
        return pref_next_i_pos;
    }
    int get_pref_next_j_pos() {
        return pref_next_j_pos;
    }*/
    bool get_light() {
        return light;
    }
    void set_light(bool light) {
        this->light = light;
    }



    void set_x(int x) {
        this->x = x;
    }
    void set_y(int y) {
        this->y = y;
    }

    void set_map_picture(HDC map_picture) {
        this->map_picture = map_picture;
    }




};
